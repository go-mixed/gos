package a

func A() string {
	return "aaa"
}
